console.log("hello world");

let a = "wfweefwe";
let b = a + "fwefwe";
let c = 3;

alert(a, b, c);
a = a + "fwe";
add(a, b, c);

(() => {
  alert("cds");
  let a = "fwefwe";
  alert(a + 3);
})();
