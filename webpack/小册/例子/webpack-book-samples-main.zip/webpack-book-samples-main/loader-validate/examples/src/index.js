import "./c";

export default "foo";
