
```
loader-custom
├─ babel.config.js
├─ dist
│  ├─ cjs.js
│  ├─ index.js
│  └─ options.json
├─ examples
│  ├─ dist
│  │  └─ main.js
│  ├─ package.json
│  ├─ src
│  │  └─ index.js
│  ├─ webpack.config.js
│  └─ yarn.lock
├─ package.json
├─ src
│  ├─ cjs.js
│  ├─ index.js
│  └─ options.json
└─ yarn.lock

```