import _ from "lodash";

console.log(_.add(1, 2));
