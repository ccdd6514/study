const num=1;
console.log(num);