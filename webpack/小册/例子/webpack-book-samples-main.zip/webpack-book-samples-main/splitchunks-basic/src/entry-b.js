// entry-b.js
import common from "./common";
