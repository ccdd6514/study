// async-module.js
import common from "./common";
