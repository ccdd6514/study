// entry-a.js
import common from "./common";
import("./async-module");
