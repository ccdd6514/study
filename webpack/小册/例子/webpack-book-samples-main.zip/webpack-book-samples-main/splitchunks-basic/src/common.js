// common.js
export default "common chunk";
