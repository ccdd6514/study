<template>
  <div>
    <h2>Root</h2>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
