<template>
  <div>
    <h3>Home Page</h3>
    <ul>
      <li>
        <router-link to="/foo">foo</router-link>
      </li>
      <li>
        <router-link to="/bar">bar</router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>
