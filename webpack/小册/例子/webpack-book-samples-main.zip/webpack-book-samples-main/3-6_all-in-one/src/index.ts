const say = (statements: string) => {
    console.log(statements)
};

// @ts-ignore
say("Tecvan");