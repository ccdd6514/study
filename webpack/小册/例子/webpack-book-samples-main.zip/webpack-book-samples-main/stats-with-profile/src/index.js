import foo from "./foo";
import("./bar");
