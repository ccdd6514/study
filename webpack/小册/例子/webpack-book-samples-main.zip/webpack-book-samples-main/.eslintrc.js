module.exports = {
    "extends": "standard"
}