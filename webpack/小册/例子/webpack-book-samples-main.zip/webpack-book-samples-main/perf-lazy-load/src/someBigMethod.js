export default function aBigFunction() {}
