import bar from "./bar";

console.log(bar);
console.log("index");
