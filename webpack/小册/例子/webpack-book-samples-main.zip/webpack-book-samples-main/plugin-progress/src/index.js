import foo from "./foo";

// console.log(_.identity(foo));

console.log(PROD, VERSION);
