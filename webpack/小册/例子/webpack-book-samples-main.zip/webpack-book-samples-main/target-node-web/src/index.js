import("./foo").then(console.log);
