export default "sync-c";
