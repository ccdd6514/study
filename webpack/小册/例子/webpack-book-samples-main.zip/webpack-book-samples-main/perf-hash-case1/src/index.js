import "./sync-a";
import "./sync-b";

import("./async-a");
