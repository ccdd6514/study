export default "sync-a";
