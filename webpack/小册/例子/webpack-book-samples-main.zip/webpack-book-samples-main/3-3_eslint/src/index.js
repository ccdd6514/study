const foo = 'foo';
let bar = 'bar';

console.log(foo, bar)