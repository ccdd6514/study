
```
MF-basic
├─ app-1
│  ├─ dist
│  │  ├─ main.js
│  │  ├─ remoteEntry.js
│  │  └─ src_utils_js.js
│  ├─ package.json
│  ├─ src
│  │  ├─ main.js
│  │  └─ utils.js
│  └─ webpack.config.js
├─ app-2
│  ├─ dist
│  │  ├─ index.html
│  │  └─ main.js
│  ├─ package.json
│  ├─ src
│  │  ├─ bootstrap.js
│  │  └─ main.js
│  ├─ webpack.config.js
│  └─ yarn.lock
├─ lerna.json
├─ package.json
└─ yarn.lock

```