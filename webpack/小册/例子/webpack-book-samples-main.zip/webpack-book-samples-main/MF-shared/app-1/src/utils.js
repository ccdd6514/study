import _ from "lodash";

export const sayHello = () => {
  console.log("hello world!", _.add(1, 2));
};
