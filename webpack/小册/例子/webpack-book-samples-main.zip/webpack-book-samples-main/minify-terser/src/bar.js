console.log("hello world");

const a = 0;
const b = 2;
const c = 3;
alert(3);

import ad from "./lib/a";
alert(ad);
