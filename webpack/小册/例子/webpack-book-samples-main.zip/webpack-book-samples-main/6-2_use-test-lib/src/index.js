import { add } from "6-1_test-lib";

console.log(add(1, 2));
