import { add } from "lodash";

export const add1 = add;
console.log("abcs");
