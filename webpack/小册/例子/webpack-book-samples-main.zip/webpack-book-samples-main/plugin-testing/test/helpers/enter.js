// Entry point for tests
