import { createSSRApp } from "vue";
import App from "./App.vue";

createSSRApp(App).mount("#app");
