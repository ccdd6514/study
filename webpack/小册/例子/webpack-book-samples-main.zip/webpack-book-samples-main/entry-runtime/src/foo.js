import("./bar");

console.log(bar);
console.log("foo");
