module.exports = () => {
  return 'module.exports = null';
};
