export const sayHello = () => {
  alert("hello world!");
};
