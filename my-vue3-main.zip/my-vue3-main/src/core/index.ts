// import './effect/effect';
import './diff';

const sum = (a: number, b: number): number => {
  return a + b;
};

export { sum };
