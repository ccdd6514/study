// postcss-loader的配置文件,会自动读取配置
// autoprefixer 根据 .browserslistrc文件 决定添加哪些浏览器前缀到css中
module.exports = {
  plugins: ['autoprefixer'],
};
