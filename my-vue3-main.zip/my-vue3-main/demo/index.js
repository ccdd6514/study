import { sum } from '../src';

console.log('a+b', sum(1, 3));
